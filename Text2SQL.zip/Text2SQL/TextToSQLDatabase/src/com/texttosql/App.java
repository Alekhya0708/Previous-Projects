package com.texttosql;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class App 
{
	static String myfile="";
	public static void main(String args[]) {
		int finalCode = 0;
		try {
			File sourceFile =new File("C:/Users/alekh/OneDrive/Desktop/Java/Hello_world/Text2SQL/TextFile/SAPFILE");
			myfile =sourceFile.getCanonicalPath();
			finalCode=readTxtFile(sourceFile);
			if(finalCode==1) {
				System.out.println("sucess");
			}
			else {
				System.out.println("error");
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static int maxindex(int max_Identity) throws SQLException{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/textdb","root","987654321");
			Statement st = con.createStatement();
			ResultSet idMax = st.executeQuery("SELECT max(id) as id from test3");
			if (idMax.next()) {
				max_Identity = idMax.getInt("id");  
			   System.out.println("max_Identity:"+max_Identity);
			}
		}catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return max_Identity;
	}
	public static void execute(ArrayList<String> list) throws SQLException{
		PreparedStatement stmt = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/textdb","root","987654321");
			Object[] myArray = list.toArray();
			for(int i=0; i<list.size();i++) {
				stmt = con.prepareStatement((String) myArray[i]);
				stmt.execute();
			}
		}catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
private static int readTxtFile(File sourceFile) throws IOException, SQLException{
	ArrayList<String> list = new ArrayList<String>();
	int finalCode=0;
	int count=0;
	int BBSEG_ID=0;
	int max_Identity = 0;
	int max_BBSEG_ID=maxindex(max_Identity);
	System.out.println(max_BBSEG_ID);
	if(max_BBSEG_ID>1) {
		BBSEG_ID=max_BBSEG_ID;
	}
	try {
		String st;
		BufferedReader br = new BufferedReader(new FileReader(sourceFile));
		while((st = br.readLine()) != null) {
			
			if(count==0) {
				String sTYPE = st.substring(0,1).trim();
				String x_gROUP = st.substring(1,13).trim();
				String mANDT = st.substring(13,16).trim();
				String uSNAM = st.substring(16,28).trim();
				String x_sTART = st.substring(28,36).trim();
				String xKEEP = st.substring(36,37).trim();
				String nODATA = st.substring(37,38).trim();
				String fILLER = st.substring(38,3500).trim();
				String insertTableSQL = "INSERT INTO TEST1(STYPE,XGROUP,MANDT,USNAM,XSTART,XKEEP,NODATA,FILLER)"+ "VALUES("
						+"'"+sTYPE
						+"','"+x_gROUP
						+"','"+mANDT
						+"','"+uSNAM
						+"','"+x_sTART
						+"','"+xKEEP
						+"','"+nODATA
						+"','"+fILLER
						+"'"+
						")";
				list.add(insertTableSQL);
			}
			if(count>=1 && !st.startsWith("BBSEG")){
		        String bLDAT = st.substring(0,8).trim();
				String bLART = st.substring(8,10).trim();
				String bUKRS = st.substring(10,14).trim();
				String bUDAT = st.substring(14,22).trim();
				String xBLNR = st.substring(22,38).trim();
				String bKTXT = st.substring(38,63).trim();
				String bBKPF_USNAM = st.substring(63,75).trim();
				String bBKPF_FILLER = st.substring(75,3500).trim();
				String insertTableSQL = "INSERT INTO TEST2(BLDAT,BLART,BUKRS,BUDAT,XBLNR,BKTXT,BBKPF_USNAM,BBKPF_FILLER)"+ "VALUES("
						+"'"+bLDAT
						+"','"+bLART
						+"','"+bUKRS
						+"','"+bUDAT
						+"','"+xBLNR
						+"','"+bKTXT
						+"','"+bBKPF_USNAM
						+"','"+bBKPF_FILLER
						+"'"+
						")";
				list.add(insertTableSQL);
			}
			if(count>=1 && st.startsWith("BBSEG")) {
				BBSEG_ID++;
				String iNVO_NUM =st.substring(71,81).trim();
				String tBNAM = st.substring(0,30).trim();
				String nEWBS = st.substring(30,32).trim();
				String wRBTR = st.substring(32,48).trim();
				String mWSKZ = st.substring(48,50).trim();
				String zUONR = st.substring(50,68).trim();
				String sGTXT = st.substring(68,118).trim();
				String zTERM = st.substring(118,122).trim();
				String nEWKO = st.substring(122,139).trim();
				String hKONT = st.substring(139,149).trim();
				String pRCTR = st.substring(149,159).trim();
				String xREF1 = st.substring(159,179).trim();
				String xREF2 = st.substring(179,183).trim();
				String kIDNO = st.substring(183,213).trim();
				String sEGMENT= st.substring(213,223).trim();
				String kTOSL = st.substring(223,233).trim();
				String wAERS = st.substring(233,238).trim();
				String fWBAS = st.substring(238,254).trim();
				String sPACE = st.substring(254,270).trim();
				String bBSEG_FILLER =st.substring(270,3500).trim();
				String insertTableSQL = "INSERT INTO TEST3(id,INVO_NUM,TBNAM,NEWBS,WRBTR,MWSKZ,ZUONR,SGTXT,ZTERM,NEWKO,HKONT,PRCTR,XREF1,XREF2,KIDNO,SEGMENT,KTOSL,WAERS,FWBAS,SPACE,BBSEG_FILLER)"+ "VALUES("
						+"'"+BBSEG_ID
						+"','"+iNVO_NUM
						+"','"+tBNAM
						+"','"+nEWBS
						+"','"+wRBTR
						+"','"+mWSKZ
						+"','"+zUONR
						+"','"+sGTXT
						+"','"+zTERM
						+"','"+nEWKO
						+"','"+hKONT
						+"','"+pRCTR
						+"','"+xREF1
						+"','"+xREF2
						+"','"+kIDNO 
						+"','"+sEGMENT
						+"','"+kTOSL
						+"','"+wAERS
						+"','"+fWBAS
						+"','"+sPACE
						+"','"+bBSEG_FILLER
						+"'"+
						")";
				list.add(insertTableSQL);
				}
			count++;
			}
		System.out.println(BBSEG_ID);
		execute(list);
		finalCode =1;
		}catch (Exception e) {
		e.printStackTrace();
	}
	return finalCode;
	}
}